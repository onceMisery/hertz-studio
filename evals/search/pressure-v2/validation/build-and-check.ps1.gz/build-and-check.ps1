$ErrorActionPreference = 'Stop'
Set-Location 'D:/code/github/hertz-studio'
$env:TMP='D:/code/github/hertz-studio/target/mcp-sdk-check/tmp'
$env:TEMP=$env:TMP
$env:CARGO_INCREMENTAL='0'
$env:CARGO_PROFILE_DEV_DEBUG='0'
$env:CARGO_PROFILE_TEST_DEBUG='0'
$env:VMUSIC_BACKEND='null'
$env:VMUSIC_SECRETS='memory'
$validationRoot='target/search-pressure-v2'
foreach ($pressureEdition in @('standard','full')) {
    Write-Output "Building $pressureEdition pressure executable"
    $featureArgs = @()
    if ($pressureEdition -eq 'full') { $featureArgs = @('--features','full') }
    cargo test --locked -p hertz-studio --lib --no-run --target-dir D:/code/github/hertz-studio/target/mcp-sdk-check @featureArgs --message-format=json 1> "$validationRoot/$pressureEdition-artifacts-final.jsonl" 2> "$validationRoot/$pressureEdition-build-final.log"
    if ($LASTEXITCODE -ne 0) { throw "$pressureEdition build failed" }
    $artifactRows=Get-Content "$validationRoot/$pressureEdition-artifacts-final.jsonl" | ForEach-Object { $_ | ConvertFrom-Json }
    $artifact=$artifactRows | Where-Object { $_.reason -eq 'compiler-artifact' -and $_.target.name -eq 'hertz_studio' -and $_.profile.test -eq $true -and $_.executable }
    if (@($artifact).Count -ne 1) { throw 'Ambiguous library executable' }
    $editionDir="$validationRoot/$pressureEdition"
    New-Item -ItemType Directory -Force $editionDir | Out-Null
    if (Test-Path "$editionDir/library-test.exe") { throw 'Do not overwrite a frozen executable' }
    Copy-Item -LiteralPath $artifact.executable -Destination "$editionDir/library-test.exe"
    Write-Output "Checking $pressureEdition online module"
    & "$editionDir/library-test.exe" online:: --test-threads=4 *> "$validationRoot/$pressureEdition-online.log"
    if ($LASTEXITCODE -ne 0) { throw "$pressureEdition online checks failed" }
    Write-Output "Checking $pressureEdition Clippy"
    cargo clippy --locked -p hertz-studio --all-targets --target-dir D:/code/github/hertz-studio/target/mcp-sdk-check @featureArgs -- -D warnings *> "$validationRoot/$pressureEdition-clippy.log"
    if ($LASTEXITCODE -ne 0) { throw "$pressureEdition clippy failed" }
}
Write-Output 'Checking MSRV test compilation'
cargo +1.88.0 check --locked -p hertz-studio --tests --features full --target-dir D:/code/github/hertz-studio/target/mcp-sdk-check *> "$validationRoot/msrv-tests.log"
if ($LASTEXITCODE -ne 0) { throw 'MSRV tests failed' }
cargo fmt --all --check *> "$validationRoot/fmt.log"
if ($LASTEXITCODE -ne 0) { throw 'Format failed' }
node scripts/check-adrs.js *> "$validationRoot/adrs.log"
if ($LASTEXITCODE -ne 0) { throw 'ADRs failed' }
Write-Output 'Validation complete; pressure runs can start'